﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainMenuMouseHover : MonoBehaviour {
    void Start()
    {
        GetComponent<Renderer>().material.color = Color.blue;
    }

    void OnMouseEnter()
    {
        GetComponent<Renderer>().material.color = Color.black;
    }

    void OnMouseExit()
    {
        GetComponent<Renderer>().material.color = Color.blue;
    }
}
